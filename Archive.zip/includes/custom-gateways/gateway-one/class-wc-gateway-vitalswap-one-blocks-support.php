<?php

final class WC_Gateway_VitalSwap_One_Blocks_Support extends WC_Gateway_Custom_VitalSwap_Blocks_Support {

	/**
	 * Payment method id.
	 *
	 * @var string
	 */
	protected $name = 'vitalswap-one';
}
